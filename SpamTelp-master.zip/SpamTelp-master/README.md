# Spam Call V3.0

```
Script Spam Call Versi 3.0 Ini Di Ciptakan Untuk MengePrank Temen Lu Yg Suka Mabar Game Online
Atau Ngepam Mantan Lu Juga Mantap Tuh Awokawok :v

```
# Info

```
Author Tidak Bertanggungjawab Kalo Terjadi Masalah Yg Berkaitan Dg Script Ini!!
```
